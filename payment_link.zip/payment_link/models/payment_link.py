from odoo import api, fields, models, _


class PaymentLink(models.Model):
    _name = "payment.link"

