from odoo import api, fields, models, _

class MilestoneTask(models.Model):
    _name = "milestone.task"



