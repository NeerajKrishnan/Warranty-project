from odoo import api, fields, models, _


class CreateWarningApproval(models.TransientModel):
    _name = 'create.warning.approval'
    _description = 'warrant app'
